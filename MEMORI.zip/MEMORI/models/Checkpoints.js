import Sequelize from "sequelize";
import connection from "../config/sequelize-config";

const Checkpoints = connection.define('checkpoints',{
    nome_checkpoint:{
        type: Sequelize.STRING,
        allowNull: false,
    },
    latitude_checkpoint:{
        type: Sequelize.FLOAT,
        allowNull: false, 
    },
    longitude_checkpoint:{
        type: Sequelize.FLOAT,
        allowNull: false,
    },
    // CHAVE ESTRANGEIRA?????
    id_trajeto:{
        type: Sequelize.INTEGER,
        allowNull: false,
    }
})
Checkpoints.sync({forse:false});
export default Checkpoints;