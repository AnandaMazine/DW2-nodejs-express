import Sequelize from "sequelize";
import connection from "../config/sequelize-config";

const Usuarios = connection.define('Usuarios',{
    nome_usuario_completo:{
        type: Sequelize.STRING,
        allowNull: false,
    },
    nickname:{
        type: Sequelize.STRING,
        allowNull: false, 
    },
    email_usuario:{
        type: Sequelize.STRING,
        allowNull: false,
    },
    senha_usuario:{
        type: Sequelize.STRING,
        allowNull: false,
    },
})
Usuarios.sync({forse:false});
export default Usuarios;